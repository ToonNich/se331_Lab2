<script setup lang="ts">
import { toRefs, defineProps } from 'vue'
import { type Event } from '@/types'

const props = defineProps<{
  event: Event
  id: String
}>()

const { event } = toRefs(props)
</script>

<template>
  <p>Edit event here</p>
</template>
